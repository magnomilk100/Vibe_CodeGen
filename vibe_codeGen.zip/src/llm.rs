// Handles LLM provider communication (OpenAI, Anthropic, Ollama)
