// Utility functions (e.g., progress bar, git integration)
